import React, { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, addDoc, getDocs, updateDoc, doc, deleteDoc, query, where } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { 
  LayoutDashboard, 
  UserPlus, 
  CalendarPlus, 
  Users, 
  History, 
  Package, 
  DollarSign, 
  UserRound,
  Search,
  Printer,
  Bell,
  Edit,
  Trash2,
  Phone,
  Eye,
  Plus,
  Minus,
  Save
} from 'lucide-react';

// Type definitions
interface Patient {
  id: string;
  name: string;
  phone: string;
  age: string;
  gender: string;
  address: string;
  medicalHistory: string;
  nextAppointment: string | null;
}

interface Visit {
  id?: string;
  visitId: number;
  patientId: string;
  date: string;
  treatment: string;
  doctor: string;
  cost: number;
  status: string;
  nextAppointment: string | null;
}

interface InventoryItem {
  id?: string;
  name: string;
  quantity: number;
}

interface Expense {
  id?: string;
  date: string;
  category: string;
  amount: number;
  description: string;
}

export default function Dashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Clinic Settings State
  const [clinicName, setClinicName] = useState(localStorage.getItem('clinicName') || 'Your Clinic');
  const [doctorName, setDoctorName] = useState(localStorage.getItem('doctorName') || 'Doctor');
  const [showSettings, setShowSettings] = useState(false);
  
  // Data State
  const [patients, setPatients] = useState<Patient[]>([]);
  const [visits, setVisits] = useState<Visit[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  
  // Loading State
  const [loading, setLoading] = useState(true);

  // Form States
  const [newPatient, setNewPatient] = useState({ name: '', phone: '', age: '', gender: '', address: '', medicalHistory: '' });
  const [newVisit, setNewVisit] = useState({ patientId: '', date: new Date().toISOString().split('T')[0], treatment: [] as string[], doctor: '', cost: '', status: 'Paid', nextAppointment: '' });
  const [newMaterial, setNewMaterial] = useState({ name: '', quantity: '' });
  const [newExpense, setNewExpense] = useState({ date: new Date().toISOString().split('T')[0], category: '', amount: '', description: '' });

  // Patient History State
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [selectedTeeth, setSelectedTeeth] = useState<number[]>([]);
  const [historyForm, setHistoryForm] = useState({ chiefComplaint: '', diagnosis: '', treatmentPlan: '', notes: '' });

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [financialRange, setFinancialRange] = useState({ start: '2020-01-01', end: '2030-12-31' });
  const [doctorRange, setDoctorRange] = useState({ start: '2020-01-01', end: '2030-12-31' });

  // Collections
  const patientsCollection = collection(db, 'patients');
  const visitsCollection = collection(db, 'visits');
  const inventoryCollection = collection(db, 'inventory');
  const expensesCollection = collection(db, 'expenses');

  // Initial Data Load
  useEffect(() => {
    const loadData = async () => {
      try {
        const patientsSnapshot = await getDocs(patientsCollection);
        const visitsSnapshot = await getDocs(visitsCollection);
        const inventorySnapshot = await getDocs(inventoryCollection);
        const expensesSnapshot = await getDocs(expensesCollection);

        setPatients(patientsSnapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Patient)));
        setVisits(visitsSnapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Visit)));
        setInventory(inventorySnapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as InventoryItem)));
        setExpenses(expensesSnapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Expense)));
        
        setLoading(false);
      } catch (error) {
        console.error("Error loading data:", error);
        toast({ title: "Error loading data", description: "Check your connection", variant: "destructive" });
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // --- Actions ---

  const handleAddPatient = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const docRef = await addDoc(patientsCollection, { ...newPatient, nextAppointment: null });
      setPatients([...patients, { ...newPatient, id: docRef.id, nextAppointment: null }]);
      toast({ title: "Success", description: "Patient added successfully" });
      setNewPatient({ name: '', phone: '', age: '', gender: '', address: '', medicalHistory: '' });
    } catch (error) {
      console.error("Error adding patient:", error);
      toast({ title: "Error", description: "Could not add patient", variant: "destructive" });
    }
  };

  const handleAddVisit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVisit.patientId || newVisit.treatment.length === 0) {
      toast({ title: "Error", description: "Please fill all required fields", variant: "destructive" });
      return;
    }

    try {
      const visitData = {
        visitId: Date.now(),
        patientId: newVisit.patientId,
        date: newVisit.date,
        treatment: newVisit.treatment.join(', '),
        doctor: newVisit.doctor,
        cost: parseFloat(newVisit.cost),
        status: newVisit.status,
        nextAppointment: newVisit.nextAppointment || null
      };

      const docRef = await addDoc(visitsCollection, visitData);
      setVisits([...visits, { ...visitData, id: docRef.id }]);

      // Update patient next appointment if needed
      if (newVisit.nextAppointment) {
        const patientRef = doc(db, 'patients', newVisit.patientId);
        await updateDoc(patientRef, { nextAppointment: newVisit.nextAppointment });
        setPatients(patients.map(p => p.id === newVisit.patientId ? { ...p, nextAppointment: newVisit.nextAppointment } : p));
      }

      toast({ title: "Success", description: "Visit added successfully" });
      setNewVisit({ ...newVisit, treatment: [], cost: '', nextAppointment: '' });
    } catch (error) {
      console.error("Error adding visit:", error);
      toast({ title: "Error", description: "Could not add visit", variant: "destructive" });
    }
  };

  const handleAddMaterial = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const materialData = { name: newMaterial.name, quantity: parseInt(newMaterial.quantity) };
      const docRef = await addDoc(inventoryCollection, materialData);
      setInventory([...inventory, { ...materialData, id: docRef.id }]);
      toast({ title: "Success", description: "Material added" });
      setNewMaterial({ name: '', quantity: '' });
    } catch (error) {
      toast({ title: "Error", variant: "destructive" });
    }
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const expenseData = { ...newExpense, amount: parseFloat(newExpense.amount) };
      const docRef = await addDoc(expensesCollection, expenseData);
      setExpenses([...expenses, { ...expenseData, id: docRef.id }]);
      toast({ title: "Success", description: "Expense added" });
      setNewExpense({ ...newExpense, amount: '', description: '' });
    } catch (error) {
      toast({ title: "Error", variant: "destructive" });
    }
  };

  const toggleTooth = (toothNumber: number) => {
    if (selectedTeeth.includes(toothNumber)) {
      setSelectedTeeth(selectedTeeth.filter(t => t !== toothNumber));
    } else {
      setSelectedTeeth([...selectedTeeth, toothNumber]);
    }
  };

  const savePatientHistory = () => {
    if (!selectedPatientId) {
      toast({ title: "Error", description: "Please select a patient", variant: "destructive" });
      return;
    }
    // In a real app, we'd save this to a subcollection or separate collection
    toast({ title: "Success", description: "Patient history saved (Mock)" });
  };

  // --- Dashboard Calculations ---
  const today = new Date().toISOString().split('T')[0];
  const todayVisits = visits.filter(v => v.date === today);
  const todayIncome = todayVisits.filter(v => v.status === 'Paid').reduce((sum, v) => sum + v.cost, 0);
  const lowStockItems = inventory.filter(i => i.quantity <= 2);
  
  // Monthly Profit
  const currentMonthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];
  const monthIncome = visits.filter(v => v.date >= currentMonthStart && v.status === 'Paid').reduce((sum, v) => sum + v.cost, 0);
  const monthExpenses = expenses.filter(e => e.date >= currentMonthStart).reduce((sum, e) => sum + e.amount, 0);
  const monthProfit = monthIncome - monthExpenses;

  // --- Render Helpers ---
  const renderDashboard = () => (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-500 to-cyan-700">Dashboard Overview</h2>
      
      {lowStockItems.length > 0 && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded shadow-sm">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-yellow-400">⚠️</div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                Warning! Low stock: {lowStockItems.map(i => i.name).join(', ')}
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard title="Today's Visits" value={todayVisits.length} icon={<Users className="h-8 w-8 text-white opacity-80" />} />
        <DashboardCard title="Total Patients" value={patients.length} icon={<UserPlus className="h-8 w-8 text-white opacity-80" />} />
        <DashboardCard title="Today's Income" value={`${todayIncome} EGP`} icon={<DollarSign className="h-8 w-8 text-white opacity-80" />} />
        <DashboardCard title="Monthly Profit" value={`${monthProfit} EGP`} icon={<History className="h-8 w-8 text-white opacity-80" />} />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-6 mb-8 border border-cyan-100 relative overflow-hidden">
          <div className="absolute -right-4 -top-4 text-9xl opacity-5 select-none">🦷</div>
          <div className="relative z-10 flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-500 to-cyan-700 mb-2">
                {clinicName}
              </h1>
              <p className="text-lg text-cyan-600 font-semibold">{doctorName}</p>
              <p className="text-slate-500">Management System</p>
            </div>
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-full text-sm font-semibold hover:shadow-lg transition-all"
              data-testid="button-settings"
            >
              ⚙️ Settings
            </button>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <div className="mt-6 p-4 bg-cyan-50 rounded-xl border-2 border-cyan-200 animate-in fade-in">
              <h3 className="font-semibold text-cyan-800 mb-4">Clinic Settings</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-cyan-700 mb-2">Clinic Name</label>
                  <input 
                    type="text"
                    value={clinicName}
                    onChange={(e) => setClinicName(e.target.value)}
                    className="w-full p-2 border-2 border-cyan-300 rounded-lg focus:border-cyan-500 outline-none"
                    data-testid="input-clinic-name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-cyan-700 mb-2">Doctor/Manager Name</label>
                  <input 
                    type="text"
                    value={doctorName}
                    onChange={(e) => setDoctorName(e.target.value)}
                    className="w-full p-2 border-2 border-cyan-300 rounded-lg focus:border-cyan-500 outline-none"
                    data-testid="input-doctor-name"
                  />
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <button 
                  onClick={() => {
                    localStorage.setItem('clinicName', clinicName);
                    localStorage.setItem('doctorName', doctorName);
                    toast({ title: "Success", description: "Settings saved!" });
                    setShowSettings(false);
                  }}
                  className="px-4 py-2 bg-green-500 text-white rounded-full text-sm font-semibold hover:bg-green-600"
                  data-testid="button-save-settings"
                >
                  Save
                </button>
                <button 
                  onClick={() => setShowSettings(false)}
                  className="px-4 py-2 bg-slate-300 text-slate-700 rounded-full text-sm font-semibold hover:bg-slate-400"
                  data-testid="button-cancel-settings"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex flex-wrap gap-3 mt-6">
            <NavButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<LayoutDashboard size={18} />} label="Dashboard" />
            <NavButton active={activeTab === 'add-patient'} onClick={() => setActiveTab('add-patient')} icon={<UserPlus size={18} />} label="New Patient" />
            <NavButton active={activeTab === 'add-visit'} onClick={() => setActiveTab('add-visit')} icon={<CalendarPlus size={18} />} label="Add Visit" />
            <NavButton active={activeTab === 'patients-list'} onClick={() => setActiveTab('patients-list')} icon={<Users size={18} />} label="Patients List" />
            <NavButton active={activeTab === 'patient-history'} onClick={() => setActiveTab('patient-history')} icon={<History size={18} />} label="History" />
            <NavButton active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} icon={<Package size={18} />} label="Inventory" />
            <NavButton active={activeTab === 'financial'} onClick={() => setActiveTab('financial')} icon={<DollarSign size={18} />} label="Financial" />
            <NavButton active={activeTab === 'doctors'} onClick={() => setActiveTab('doctors')} icon={<UserRound size={18} />} label="Doctors" />
          </nav>
        </header>

        {/* Content Area */}
        <main className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl border border-cyan-100 min-h-[500px] p-6 md:p-8">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && renderDashboard()}
              
              {activeTab === 'add-patient' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className="text-2xl font-bold text-cyan-700 mb-6 border-b-2 border-cyan-100 pb-2">Add New Patient</h2>
                  <form onSubmit={handleAddPatient} className="space-y-6 max-w-2xl">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormInput label="Patient Name *" value={newPatient.name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPatient({...newPatient, name: e.target.value})} required />
                      <FormInput label="Phone Number *" value={newPatient.phone} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPatient({...newPatient, phone: e.target.value})} required />
                      <FormInput label="Age *" type="number" value={newPatient.age} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPatient({...newPatient, age: e.target.value})} required />
                      <FormSelect label="Gender" value={newPatient.gender} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setNewPatient({...newPatient, gender: e.target.value})} options={['Male', 'Female']} />
                    </div>
                    <FormInput label="Address" value={newPatient.address} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPatient({...newPatient, address: e.target.value})} />
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-cyan-700">Medical History</label>
                      <textarea 
                        className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 focus:ring-0 transition-all outline-none"
                        rows={3}
                        value={newPatient.medicalHistory}
                        onChange={e => setNewPatient({...newPatient, medicalHistory: e.target.value})}
                      />
                    </div>
                    <button type="submit" className="btn-custom w-full md:w-auto">Add Patient</button>
                  </form>
                </div>
              )}

              {activeTab === 'add-visit' && (
                 <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className="text-2xl font-bold text-cyan-700 mb-6 border-b-2 border-cyan-100 pb-2">Add New Visit</h2>
                  <form onSubmit={handleAddVisit} className="space-y-6 max-w-3xl">
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-cyan-700">Select Patient *</label>
                      <select 
                        className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 outline-none"
                        value={newVisit.patientId}
                        onChange={e => setNewVisit({...newVisit, patientId: e.target.value})}
                        required
                      >
                        <option value="">-- Choose Patient --</option>
                        {patients.map(p => (
                          <option key={p.id} value={p.id}>{p.name} - {p.phone}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormInput label="Visit Date *" type="date" value={newVisit.date} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewVisit({...newVisit, date: e.target.value})} required />
                      <FormInput label="Next Appointment" type="date" value={newVisit.nextAppointment} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewVisit({...newVisit, nextAppointment: e.target.value})} />
                    </div>

                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-cyan-700">Treatments *</label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-4 border-2 border-blue-100 rounded-xl bg-white">
                        {['Cleaning', 'Filling', 'Extraction', 'Root Canal', 'Crown/Bridge', 'Scaling', 'Whitening', 'Implant', 'Orthodontic', 'Consultation'].map(t => (
                          <label key={t} className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={newVisit.treatment.includes(t)}
                              onChange={e => {
                                if (e.target.checked) setNewVisit({...newVisit, treatment: [...newVisit.treatment, t]});
                                else setNewVisit({...newVisit, treatment: newVisit.treatment.filter(x => x !== t)});
                              }}
                              className="rounded text-cyan-600 focus:ring-cyan-500"
                            />
                            <span className="text-sm text-slate-600">{t}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormInput label="Doctor Name *" value={newVisit.doctor} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewVisit({...newVisit, doctor: e.target.value})} required />
                      <FormInput label="Cost (EGP) *" type="number" value={newVisit.cost} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewVisit({...newVisit, cost: e.target.value})} required />
                    </div>

                    <button type="submit" className="btn-custom w-full md:w-auto">Add Visit</button>
                  </form>
                 </div>
              )}

              {activeTab === 'patients-list' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                    <h2 className="text-2xl font-bold text-cyan-700">Patient List</h2>
                    <div className="relative w-full md:w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" 
                        placeholder="Search..." 
                        className="w-full pl-10 pr-4 py-2 rounded-full border-2 border-blue-100 focus:border-cyan-400 outline-none"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="overflow-x-auto rounded-xl border border-cyan-100 shadow-sm">
                    <table className="w-full">
                      <thead className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white">
                        <tr>
                          <th className="p-4 text-left">Name</th>
                          <th className="p-4 text-left">Phone</th>
                          <th className="p-4 text-left">Last Visit</th>
                          <th className="p-4 text-left">Next Appt</th>
                          <th className="p-4 text-left">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-cyan-50 bg-white">
                        {patients.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.phone.includes(searchTerm)).map(patient => {
                          const patientVisits = visits.filter(v => v.patientId === patient.id);
                          const lastVisit = patientVisits.length > 0 ? patientVisits[patientVisits.length - 1].date : 'N/A';
                          
                          return (
                            <tr key={patient.id} className="hover:bg-cyan-50/50 transition-colors">
                              <td className="p-4 font-medium text-slate-700">{patient.name}</td>
                              <td className="p-4 text-slate-600">{patient.phone}</td>
                              <td className="p-4 text-slate-600">{lastVisit}</td>
                              <td className="p-4 text-cyan-600 font-medium">{patient.nextAppointment || '-'}</td>
                              <td className="p-4 flex gap-2">
                                <button className="p-2 text-blue-500 hover:bg-blue-50 rounded-full" title="Edit"><Edit size={16} /></button>
                                <button className="p-2 text-green-500 hover:bg-green-50 rounded-full" title="WhatsApp" onClick={() => window.open(`https://wa.me/${patient.phone.replace(/\D/g,'')}`, '_blank')}><Phone size={16} /></button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'patient-history' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className="text-2xl font-bold text-cyan-700 mb-6 border-b-2 border-cyan-100 pb-2">Patient History & Treatment</h2>
                  
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-cyan-700 mb-2">Select Patient</label>
                    <select 
                      className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 outline-none"
                      value={selectedPatientId}
                      onChange={e => setSelectedPatientId(e.target.value)}
                    >
                      <option value="">-- Select a Patient --</option>
                      {patients.map(p => (
                        <option key={p.id} value={p.id}>{p.name} - {p.phone}</option>
                      ))}
                    </select>
                  </div>

                  {selectedPatientId && (
                    <div className="space-y-8">
                      {/* Dental Chart */}
                      <div className="bg-white p-6 rounded-xl border border-blue-100 shadow-sm">
                        <h3 className="text-lg font-semibold text-cyan-800 mb-4 text-center">Dental Chart</h3>
                        <p className="text-center text-slate-500 mb-6 text-sm">Click on teeth to mark problems (Red = Problem)</p>
                        
                        <div className="flex flex-col gap-8">
                          {/* Upper Jaw */}
                          <div>
                            <h4 className="text-center text-cyan-600 mb-2">Upper Jaw</h4>
                            <div className="flex justify-center flex-wrap gap-2">
                              {/* Upper Right */}
                              {[18, 17, 16, 15, 14, 13, 12, 11].map(t => (
                                <div key={t} onClick={() => toggleTooth(t)} className={`tooth ${selectedTeeth.includes(t) ? 'problem' : ''}`}>{t}</div>
                              ))}
                              <div className="w-4"></div>
                              {/* Upper Left */}
                              {[21, 22, 23, 24, 25, 26, 27, 28].map(t => (
                                <div key={t} onClick={() => toggleTooth(t)} className={`tooth ${selectedTeeth.includes(t) ? 'problem' : ''}`}>{t}</div>
                              ))}
                            </div>
                          </div>

                          {/* Lower Jaw */}
                          <div>
                            <h4 className="text-center text-cyan-600 mb-2">Lower Jaw</h4>
                            <div className="flex justify-center flex-wrap gap-2">
                              {/* Lower Right */}
                              {[48, 47, 46, 45, 44, 43, 42, 41].map(t => (
                                <div key={t} onClick={() => toggleTooth(t)} className={`tooth ${selectedTeeth.includes(t) ? 'problem' : ''}`}>{t}</div>
                              ))}
                              <div className="w-4"></div>
                              {/* Lower Left */}
                              {[31, 32, 33, 34, 35, 36, 37, 38].map(t => (
                                <div key={t} onClick={() => toggleTooth(t)} className={`tooth ${selectedTeeth.includes(t) ? 'problem' : ''}`}>{t}</div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Diagnosis Form */}
                      <div className="bg-white p-6 rounded-xl border border-blue-100 shadow-sm space-y-4">
                        <h3 className="text-lg font-semibold text-cyan-800">Diagnosis & Treatment Plan</h3>
                        <div>
                          <label className="block text-sm font-medium text-cyan-700">Chief Complaint</label>
                          <textarea className="w-full p-3 rounded-xl border-2 border-blue-100 outline-none" rows={2} value={historyForm.chiefComplaint} onChange={e => setHistoryForm({...historyForm, chiefComplaint: e.target.value})} />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-cyan-700">Diagnosis</label>
                          <textarea className="w-full p-3 rounded-xl border-2 border-blue-100 outline-none" rows={2} value={historyForm.diagnosis} onChange={e => setHistoryForm({...historyForm, diagnosis: e.target.value})} />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-cyan-700">Treatment Plan</label>
                          <textarea className="w-full p-3 rounded-xl border-2 border-blue-100 outline-none" rows={3} value={historyForm.treatmentPlan} onChange={e => setHistoryForm({...historyForm, treatmentPlan: e.target.value})} />
                        </div>
                        <button onClick={savePatientHistory} className="btn-custom flex items-center gap-2">
                          <Save size={18} /> Save History
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'inventory' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                   <h2 className="text-2xl font-bold text-cyan-700 mb-6 border-b-2 border-cyan-100 pb-2">Inventory Management</h2>
                   
                   <form onSubmit={handleAddMaterial} className="flex flex-col md:flex-row gap-4 mb-8 bg-blue-50/50 p-4 rounded-xl border border-blue-100">
                     <div className="flex-1">
                       <input 
                         placeholder="Material Name" 
                         className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 outline-none"
                         value={newMaterial.name}
                         onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewMaterial({...newMaterial, name: e.target.value})}
                         required
                       />
                     </div>
                     <div className="w-32">
                       <input 
                         placeholder="Qty" 
                         type="number"
                         className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 outline-none"
                         value={newMaterial.quantity}
                         onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewMaterial({...newMaterial, quantity: e.target.value})}
                         required
                       />
                     </div>
                     <button type="submit" className="btn-custom whitespace-nowrap">Add Item</button>
                   </form>

                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                     {inventory.map(item => (
                       <div key={item.id} className={`p-4 rounded-xl border-2 flex justify-between items-center ${item.quantity <= 2 ? 'border-red-200 bg-red-50' : 'border-cyan-100 bg-white'}`}>
                         <div>
                           <h3 className="font-semibold text-slate-700">{item.name}</h3>
                           <p className={`text-sm ${item.quantity <= 2 ? 'text-red-600 font-bold' : 'text-slate-500'}`}>
                             {item.quantity <= 2 ? 'Low Stock' : 'In Stock'}
                           </p>
                         </div>
                         <div className="flex items-center gap-3">
                           <span className="text-xl font-bold text-cyan-700">{item.quantity}</span>
                           <div className="flex flex-col gap-1">
                             <button onClick={async () => {
                               const ref = doc(db, 'inventory', item.id!);
                               await updateDoc(ref, { quantity: item.quantity + 1 });
                               setInventory(inventory.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
                             }} className="p-1 bg-green-100 text-green-600 rounded hover:bg-green-200"><Plus size={14} /></button>
                             <button onClick={async () => {
                               if (item.quantity > 0) {
                                 const ref = doc(db, 'inventory', item.id!);
                                 await updateDoc(ref, { quantity: item.quantity - 1 });
                                 setInventory(inventory.map(i => i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i));
                               }
                             }} className="p-1 bg-red-100 text-red-600 rounded hover:bg-red-200"><Minus size={14} /></button>
                           </div>
                         </div>
                       </div>
                     ))}
                   </div>
                </div>
              )}

              {activeTab === 'financial' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className="text-2xl font-bold text-cyan-700 mb-6 border-b-2 border-cyan-100 pb-2">Financials</h2>
                  
                  {/* Add Expense Form */}
                  <div className="mb-8 bg-white p-6 rounded-xl border border-blue-100 shadow-sm">
                    <h3 className="text-lg font-semibold text-slate-700 mb-4">Add Expense</h3>
                    <form onSubmit={handleAddExpense} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <input type="date" value={newExpense.date} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewExpense({...newExpense, date: e.target.value})} className="p-3 rounded-xl border-2 border-blue-100 outline-none" />
                      <select value={newExpense.category} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setNewExpense({...newExpense, category: e.target.value})} className="p-3 rounded-xl border-2 border-blue-100 outline-none" required>
                        <option value="">Category</option>
                        <option value="Rent">Rent</option>
                        <option value="Salaries">Salaries</option>
                        <option value="Materials">Materials</option>
                        <option value="Other">Other</option>
                      </select>
                      <input type="number" placeholder="Amount" value={newExpense.amount} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewExpense({...newExpense, amount: e.target.value})} className="p-3 rounded-xl border-2 border-blue-100 outline-none" required />
                      <button type="submit" className="btn-custom">Add</button>
                    </form>
                  </div>

                  {/* Report Range */}
                  <div className="flex gap-4 mb-6 items-end">
                    <div>
                      <label className="text-sm text-slate-500 block mb-1">From</label>
                      <input type="date" value={financialRange.start} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFinancialRange({...financialRange, start: e.target.value})} className="p-2 border rounded" />
                    </div>
                    <div>
                      <label className="text-sm text-slate-500 block mb-1">To</label>
                      <input type="date" value={financialRange.end} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFinancialRange({...financialRange, end: e.target.value})} className="p-2 border rounded" />
                    </div>
                  </div>

                  {/* Summary Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-green-50 p-6 rounded-xl border border-green-100">
                      <h3 className="text-green-800 font-medium mb-2">Total Income</h3>
                      <p className="text-3xl font-bold text-green-600">
                        {visits.filter(v => v.date >= financialRange.start && v.date <= financialRange.end && v.status === 'Paid').reduce((sum, v) => sum + v.cost, 0)} EGP
                      </p>
                    </div>
                    <div className="bg-red-50 p-6 rounded-xl border border-red-100">
                      <h3 className="text-red-800 font-medium mb-2">Total Expenses</h3>
                      <p className="text-3xl font-bold text-red-600">
                        {expenses.filter(e => e.date >= financialRange.start && e.date <= financialRange.end).reduce((sum, e) => sum + e.amount, 0)} EGP
                      </p>
                    </div>
                    <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                      <h3 className="text-blue-800 font-medium mb-2">Net Profit</h3>
                      <p className="text-3xl font-bold text-blue-600">
                        {(visits.filter(v => v.date >= financialRange.start && v.date <= financialRange.end && v.status === 'Paid').reduce((sum, v) => sum + v.cost, 0) - 
                          expenses.filter(e => e.date >= financialRange.start && e.date <= financialRange.end).reduce((sum, e) => sum + e.amount, 0))} EGP
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'doctors' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className="text-2xl font-bold text-cyan-700 mb-6 border-b-2 border-cyan-100 pb-2">Doctor Performance</h2>
                   <div className="overflow-x-auto rounded-xl border border-cyan-100 shadow-sm">
                    <table className="w-full">
                      <thead className="bg-slate-100 text-slate-700">
                        <tr>
                          <th className="p-4 text-left">Doctor</th>
                          <th className="p-4 text-left">Total Cases</th>
                          <th className="p-4 text-left">Revenue</th>
                          <th className="p-4 text-left">Share (30%)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {/* Aggregate Doctor Stats */}
                        {Array.from(new Set(visits.map(v => v.doctor))).map(doctor => {
                          const docVisits = visits.filter(v => v.doctor === doctor && v.status === 'Paid');
                          const revenue = docVisits.reduce((sum, v) => sum + v.cost, 0);
                          return (
                            <tr key={doctor}>
                              <td className="p-4 font-medium">{doctor}</td>
                              <td className="p-4">{docVisits.length}</td>
                              <td className="p-4 text-green-600 font-medium">{revenue} EGP</td>
                              <td className="p-4 text-blue-600 font-bold">{(revenue * 0.3).toFixed(2)} EGP</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}

// Component Helpers
const DashboardCard = ({ title, value, icon }: { title: string, value: string | number, icon: React.ReactNode }) => (
  <div className="dashboard-card p-6 rounded-2xl relative overflow-hidden group">
    <div className="relative z-10">
      <h3 className="text-white/80 text-sm font-medium uppercase tracking-wider mb-2">{title}</h3>
      <p className="text-4xl font-bold text-white">{value}</p>
    </div>
    <div className="absolute right-4 bottom-4 opacity-20 transform group-hover:scale-110 transition-transform duration-500">
      {icon}
    </div>
  </div>
);

const NavButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button 
    onClick={onClick}
    className={`nav-btn-custom flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all duration-300 ${active ? 'active shadow-lg scale-105' : 'opacity-80 hover:opacity-100'}`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

const FormInput = ({ label, type = "text", value, onChange, required = false }: any) => (
  <div className="space-y-2">
    <label className="block text-sm font-medium text-cyan-700">{label}</label>
    <input 
      type={type} 
      className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 focus:ring-0 transition-all outline-none"
      value={value}
      onChange={onChange}
      required={required}
    />
  </div>
);

const FormSelect = ({ label, value, onChange, options }: any) => (
  <div className="space-y-2">
    <label className="block text-sm font-medium text-cyan-700">{label}</label>
    <select 
      className="w-full p-3 rounded-xl border-2 border-blue-100 focus:border-cyan-400 focus:ring-0 transition-all outline-none"
      value={value}
      onChange={onChange}
    >
      <option value="">Select...</option>
      {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
    </select>
  </div>
);
