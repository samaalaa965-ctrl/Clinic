import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB8tzIMXneMxBS9RWA6AUelH_-V2TMnwBM",
  authDomain: "cliniccrm-c7936.firebaseapp.com",
  projectId: "cliniccrm-c7936",
  storageBucket: "cliniccrm-c7936.firebasestorage.app",
  messagingSenderId: "465279641282",
  appId: "1:465279641282:web:5a492919e75c89acbd3d5b"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
